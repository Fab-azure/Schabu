import React from 'react';

class Thank_you extends React.Component{
    render(){
        return(
            <div className="">
                <h1>Thank you for registration, you will get an email!</h1>
            </div>
        )
    }
}

export default Thank_you;