const questions = [
    {
        key : 1,
        question: "What are your strengths?",
        recCounter: 3
    },
    {
        key : 2,
        question: "What are your weaknesses?",
        recCounter: 3
        
    },
    {
        key : 3,
        question: "Why are you interested in working for [insert company name here]?",
        recCounter: 3
       
    },
    {
        key : 4,
        question: "Where do you see yourself in five years? Ten years?",
        recCounter: 3
        
    },
    {
        key : 5,
        question: "Why do you want to leave your current company?",
        recCounter: 3
       
    },
    {
        key : 6,
        question: "Why was there a gap in your employment between [insert date] and [insert date]?",
        recCounter: 3
        
    },
    {
        key : 7,
        question: "What can you offer us that someone else can not?",
        recCounter: 3
       
    },
    {
        key : 8,
        question: "What are three things your former manager would like you to improve on?",
        recCounter: 3
       
    },
    {
        key : 9,
        question: "Are you willing to relocate?",
        recCounter: 3
       
    },
    {
        key : 10,
        question: "Are you willing to travel?",
        recCounter: 3
        
    },
]

export default questions;