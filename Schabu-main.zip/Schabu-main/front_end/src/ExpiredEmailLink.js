import React from 'react'

class ExpiredEmailLink extends React.Component{
    render(){
        return(
            <div className="">
                <h1>Soory your link is no longer a valid link!</h1>
            </div>
        )
    }
}

export default ExpiredEmailLink;